// +build testtools

package main

func main() {
}

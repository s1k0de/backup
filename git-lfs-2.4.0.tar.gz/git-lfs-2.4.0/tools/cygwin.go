// +build !windows

package tools

func isCygwin() bool {
	return false
}

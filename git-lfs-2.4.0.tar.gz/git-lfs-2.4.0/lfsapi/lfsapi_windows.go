// +build windows

package lfsapi

var netrcBasename = "_netrc"
